def main(sample):
    filename = "./{0}/{1}.txt".format(__file__.split('\\')[-2], "sample" if sample else "input")
    with open(filename) as f:
        sums = list(map(lambda arr: sum(list(map(int, arr.split("_")))), "_".join(f.read().splitlines()).split("__")))
        print('Part 1', max(sums), '\nPart 2', sum(sorted(sums, reverse=True)[:3]))

main(True)
print("-"*20)
main(False)