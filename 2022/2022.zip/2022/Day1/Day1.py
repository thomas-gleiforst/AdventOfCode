def main(sample):
    filename = "./{0}/{1}.txt".format(__file__.split('\\')[-2], "sample" if sample else "input" )
    with open(filename) as f:
        lines = f.read().splitlines()
        
        sums, elf = [], 0
        for line in lines:
            if line:
                elf += int(line)
            else:
                sums.append(elf)
                elf = 0

        print('Part 1', max(sums))
        print('Part 2', sum(sorted(sums, reverse=True)[:3]))

main(True)
print("-"*20)
main(False)