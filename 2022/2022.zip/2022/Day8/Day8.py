class tree:
    def __init__(self, x, y, size, visible=None):
        self.x = x
        self.y = y
        self.size = size
        self.visible = visible
        self.score = 1
    
    def check(self, dir):
        score = 1
        for next in dir:
            if next.size >= self.size:
                self.score *= score
                return False
            else:
                score += 1
        self.score *= score-1
        return True

    def calc(self, grid, tGrid):
        if self.visible != None: return self

        left = self.check(grid[self.y][self.x-1::-1])
        right = self.check(grid[self.y][self.x+1:])
        up = self.check(tGrid[self.x][self.y-1::-1])
        down = self.check(tGrid[self.x][self.y+1:])

        self.visible = left or right or up or down
        return self
            
def main(sample):
    filename = "./{0}/{1}.txt".format(__file__.split('\\')[-2], "sample" if sample else "input" )
    with open(filename) as f:
        lines = [list(map(int, list(line))) for line in f.read().splitlines()]
        rows, cols = len(lines), len(lines[0])

        trees = []
        for i in range(rows):
            trees.append([])
            for j in range(cols):
                if i == 0 or i == rows-1 or j == 0 or j == cols-1:
                    trees[i].append(tree(j, i, lines[i][j], visible=True))
                else:
                    trees[i].append(tree(j, i, lines[i][j]))
        tTrees = [[trees[j][i] for j in range(rows)] for i in range(cols)]

        flat = [item.calc(trees, tTrees) for row in trees for item in row]
        print('Part 1', len(list(filter(lambda x: x.visible, flat))))
        print('Part 2', sorted(flat, key=(lambda x: x.score), reverse=True)[0].score)

main(True)
print("-"*20)
main(False)