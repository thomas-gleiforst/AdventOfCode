def main(sample):
    filename = "./{0}/{1}.txt".format(__file__.split('\\')[-2], "sample" if sample else "input" )
    with open(filename) as f:
        lines = f.read().splitlines()
        vals = {'A': 1, 'B': 2, 'C': 3, 'X': 1, 'Y': 2, 'Z': 3}
        def status (r, l):
            if r == l: return 3
            if r == (l - 3) % 3 + 1: return 6
            return 0

        sums = 0
        for line in lines:
            his, yours = list(map(lambda val: vals[val], line.split()))
            sums += status(yours, his) + yours

        print('Part 1', sums)

main(True)
print("-"*20)
main(False)