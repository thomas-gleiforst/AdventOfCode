def main(sample):
    filename = "./{0}/{1}.txt".format(__file__.split('\\')[-2], "sample" if sample else "input" )
    with open(filename) as f:
        lines = f.read().splitlines()
        vals = {'A': 1, 'B': 2, 'C': 3, 'X': 'lose', 'Y': 'draw', 'Z': 'win'}
        def move(them, status):
            if status == 'draw': return them, 3
            if status == 'win': return (them - 3) % 3 + 1, 6
            if status == 'lose': return (them - 2) % 3 + 1, 0

        sums = 0
        for line in lines:
            his, status = list(map(lambda val: vals[val], line.split()))
            yours, score = move(his, status)
            sums += yours + score

        print('Part 2', sums)

main(True)
print("-"*20)
main(False)