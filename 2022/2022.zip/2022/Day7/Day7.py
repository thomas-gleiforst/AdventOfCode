under100000 = 0
directories = []

def calcSize(val):
    global under100000
    global directories

    size = 0
    for child in val.values():
        if isinstance(child, str):
            size += int(child)
        else:
            childSize = calcSize(child)
            size += childSize
    if size < 100_000:
        under100000 += size

    directories.append(size)
    return size

def main(sample):
    global under100000
    under100000 = 0

    global directories
    directories = []

    filename = "./{0}/{1}.txt".format(__file__.split('\\')[-2], "sample" if sample else "input" )
    with open(filename) as f:
        lines = f.read().splitlines()
        fileSystem = {}
        previous = []
        current = {}
        for line in lines:
            if line[0] == '$':
                if line[2:] == 'ls':
                    continue
                else:
                    cd, folder = line[2:].split()
                    if folder == '/':
                        previous = []
                        current = fileSystem
                    elif folder == '..':
                        current = previous.pop()
                    else:
                        previous.append(current)
                        current = current[folder]
            else:
                size, file = line.split()
                if file in current:
                    continue
                if size == 'dir':
                    current[file] = {}
                else:
                    current[file] = size
        fsSize = calcSize(fileSystem)
        print('Part 1', under100000)

        needed = 30000000 - (70000000 - fsSize)
        print('Part 2', next(folder for folder in sorted(directories) if folder >= needed))

main(True)
print("-"*20)
main(False)


# Helpers

def printFilesystem(files, head=""):
    out = ""
    if isinstance(files, str):
        return " - " + files
    for key in files:
        fs = ""
        if isinstance(files, dict):
            fs = printFilesystem(files[key], head+"|-->\t\t")
            out += "\n" + head + key + fs
    return out