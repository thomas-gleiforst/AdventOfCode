def main(sample):
    filename = "./{0}/{1}.txt".format(__file__.split('\\')[-2], "sample" if sample else "input" )
    with open(filename) as f:
        line = f.read()
        packetFound = False
        for i in range(4, len(line)):
            if len(set(line[i-4:i])) == 4:
                if not packetFound: 
                    print('Part 1', i)
                    packetFound = True
            if i-14 > 0 and len(set(line[i-14:i])) == 14:
                print('Part 2', i)
                return


main(True)
print("-"*20)
main(False)