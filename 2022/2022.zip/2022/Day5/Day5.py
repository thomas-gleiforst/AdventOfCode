from collections import deque

def main(sample):
    filename = "./{0}/{1}.txt".format(__file__.split('\\')[-2], "sample" if sample else "input" )
    with open(filename) as f:
        lines = f.read().splitlines()
        stacks = {key : deque() for key in range(1,(len(lines[0])+1)//4+1)}
        read = False
        for line in lines:
            if not line:
                read = True
            elif not read:
                for i in range(1, len(line), 4):
                    if line[i].isalpha():
                        stacks[i//4+1].append(line[i])
            else:
                _, count, _, src, _, dest = line.split()
                for i in range(int(count)):
                    stacks[int(dest)].appendleft(stacks[int(src)].popleft())
        out = ""
        for stack in stacks.values():
            out += stack.popleft()
        print(out)


main(True)
print("-"*20)
main(False)